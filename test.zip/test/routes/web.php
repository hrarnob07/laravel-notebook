<?php

Auth::routes();

//Route::get('/home', 'HomeController@index');


Route::group(['middleware'=>'auth'],function()
       {
       
        Route::get('/', function ()
         {
          return view('forntpage');
          });

        Route::get('/notebooks','NotebooksController@index')->name('home');
        Route::post('/notebooks','NotebooksController@store');
        Route::get('/notebooks/create','NotebooksController@create')->name('newnote');

        Route::get('/notebooks/{notebook}','NotebooksController@show')->name('notebooks.show');

        Route::get('/notebooks/{notebook}/edit','NotebooksController@edit')->name('notebooks.edit');
        Route::put('/notebooks/{notebook}','NotebooksController@update');
        Route::delete('/notebooks/{notebook}','NotebooksController@destroy');

        Route::resource('notes','NotesController');
        Route::get('notes/{notebookId}/createNote','NotesController@createNote')->name('notes.createNote');


       });




