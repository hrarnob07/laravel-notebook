@extends('layout.base')
@section('content')
<div class="container">
 <h1>CREATE NOTEBOOKS</h1>

   <form action="/notebooks" method="post">
   {{csrf_field()}}
      <div class="form-group">
          <label>Notebook Name</label>
   	      <input class="form-control" type="text" name="name">
  
    </div>
          <input class="btn btn-primery" type="submit" value ="Done">
   </form>
</div>
@endsection