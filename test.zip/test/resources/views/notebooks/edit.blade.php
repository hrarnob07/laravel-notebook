@extends('layout.base')
@section('content')
<div class="container">
 <h1>EDIT NOTE</h1>

   <form action="{{route('notes.update',$note-id)}}" method="post">
   {{csrf_field()}}
   {{method_field('PUT')}}
      <div class="form-group">
            <label for="title">
                Note Title
            </label>
            <input class="form-control" name="title" placeholder="Note Title" type="text">
            
        </div>

        <div class="form-group">
            <label for="body">
                Notes
            </label>
            <input class="form-control" name="body" placeholder="Notes" type="textarea" rows="3">
        </div>
        <input type="hidden" name="notebook_id" value={{$notebookId}}>
        <input type="submit" class="btn btn-primary" value="Done">
    </form>
</div>
@endsection