@extends('layout.base');
@section('content')
   <div class="content">
        <div class="row">

          <h3 class="display-3">
            {{$note->title}}

          	
          </h3>
         <p>{{$note->body}} </p>

        </div>

   	
   </div>

@endsection