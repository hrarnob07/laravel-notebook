<?php $__env->startSection('content'); ?>
   <!-- Main component for call to action -->
            <div class="container">
                <h1 class="pull-xs-left">
                    Notes
                </h1>
                <div class="pull-xs-right">
                    <a class="btn btn-primary" href="<?php echo e(route('notes.createNote',$notebook->id)); ?>" role="button">
                        New Note +
                    </a>
                </div>
                <div class="clearfix">
                </div>
                <!--============= notes=========== -->
                <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="list-group notes-group">

                    <!--note1 -->
                    <div class="card card-block">
                        <a href="<?php echo e(route('notes.show',$note->id)); ?>">
                            <h4 class="card-title">
                                <?php echo e($note->title); ?>

                            </h4>
                        </a>
                        <p class="card-text">
                            <?php echo e($note->body); ?>

                        </p>
                        <a class="btn btn-sm btn-info pull-xs-left" href="<?php echo e(route('notes.edit',$note->id)); ?>">
                Edit
            </a>
            <form class="pull-xs-right" action="<?php echo e(route('notes.destroy',$note->id)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

                <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                
            </form>
                    </div>
                                     
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <!-- /container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>