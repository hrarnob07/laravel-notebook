;
<?php $__env->startSection('content'); ?>
   <div class="content">
        <div class="row">

          <h3 class="display-3">
            <?php echo e($note->title); ?>


          	
          </h3>
         <p><?php echo e($note->body); ?> </p>

        </div>

   	
   </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>