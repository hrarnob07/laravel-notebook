<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>NoteBook App</title>
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap.css')); ?>">
</head>

<body>
    <div class="container-fluid">
        <nav class="navbar  navbar-dark bg-primary">
            <button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#navbar-header" aria-controls="navbar-header">
                &#9776;
            </button>
            <div class="collapse navbar-toggleable-xs" id="navbar-header">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">NoteBook App</a>
           <!-- Right Side Of Navbar -->
                    
                        <!-- Authentication Links -->
               </div>
                  <ul class="dropdown">
                    <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>       


        </nav>
        <!-- /navbar -->
        <!-- Main component for call to action -->
       <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- /container -->

    <script src="<?php echo e(asset('dist/js/jquery3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/bootstrap.js')); ?>"></script>
</body>

</html>
