<?php $__env->startSection('content'); ?>
<div class="container">
 <h1>EDIT NOTEBOOKS</h1>

   <form action="/notebooks/<?php echo e($notebook->id); ?>" method="post">
   <?php echo e(csrf_field()); ?>

   <?php echo e(method_field('PUT')); ?>

      <div class="form-group">
          <label>Notebook Name</label>
   	      <input class="form-control" type="text" name="name">
   
  
    </div>
          <input class="btn btn-primery" type="submit" value ="Update">
   </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>